package com.project.MentorOnDemand.model;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "payments")

public class Payments {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "mentor_id")
	private Long mentorId;

	@Column(name = "training_id")
	private Long trainingId;
	
	@Column(name = "amount")
	private Float amount;
	
	@Column(name = "txn_type")
	private String txnType;
	
	@Column(name = "date")
	private Date date;
	
	@Column(name = "time")
	private Time time;
	
	@Column(name = "remarks")
	private String remarks;

	public Payments() {
	}
	
	public Payments(long id, Long mentorId, Long trainingId, Float amount, String txnType, Date date, Time time,
			String remarks) {
		super();
		this.id = id;
		this.mentorId = mentorId;
		this.trainingId = trainingId;
		this.amount = amount;
		this.txnType = txnType;
		this.date = date;
		this.time = time;
		this.remarks = remarks;
	}

	public Long getId() {
		return id;
	}

	public Long getMentorId() {
		return mentorId;
	}

	public void setMentorId(Long mentorId) {
		this.mentorId = mentorId;
	}

	public Long getTrainingId() {
		return trainingId;
	}

	public void setTrainingId(Long trainingId) {
		this.trainingId = trainingId;
	}

	public Float getAmount() {
		return amount;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Time getTime() {
		return time;
	}

	public void setTime(Time time) {
		this.time = time;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "Payments [id=" + id + ", mentorId=" + mentorId + ", trainingId=" + trainingId + ", amount=" + amount
				+ ", txnType=" + txnType + ", date=" + date + ", time=" + time + ", remarks=" + remarks + "]";
	}
	
}
